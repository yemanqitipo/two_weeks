package stone.ast;

import java.util.List;

public class NullStmnt extends ASTList {
    public NullStmnt(List<ASTree> c) {
        super(c);
    }
}
