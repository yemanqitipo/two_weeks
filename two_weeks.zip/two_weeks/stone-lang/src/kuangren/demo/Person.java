package kuangren.demo;

public class Person {
    public void say() {
        System.out.println("person say funtion");
    }
}
