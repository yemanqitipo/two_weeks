package kuangren.demo;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Person person = new Person();
        Student student = new Student();
        Teacher teacher =  new Teacher();
//
//        person.say();
//        student.say();
//        teacher.say();

        List<Object> list = new ArrayList<>();
        list.add(person);
        list.add(student);
        list.add(teacher);
        for (Object o : list) {
            ((Person)o).say();
        }
    }
}
