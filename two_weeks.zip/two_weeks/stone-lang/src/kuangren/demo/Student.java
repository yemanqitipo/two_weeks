package kuangren.demo;

public class Student extends Person{
    @Override
    public void say() {
        System.out.println("student say");
    }
}
