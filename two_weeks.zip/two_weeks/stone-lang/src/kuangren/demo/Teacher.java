package kuangren.demo;

public class Teacher extends Person{
    @Override
    public void say() {
        System.out.println("teacher say");
    }
}
