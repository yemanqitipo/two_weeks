while i < 10 {
	sum = sum + i
	i = i + 1
}
sum